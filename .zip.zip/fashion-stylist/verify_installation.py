"""
Installation Verification Script
Run this to verify everything is set up correctly
"""

import os
import sys
import subprocess

def print_header(text):
    print(f"\n{'='*50}")
    print(f"  {text}")
    print(f"{'='*50}\n")

def check_python():
    """Check Python version"""
    print("✓ Python Version:", sys.version.split()[0])
    if sys.version_info < (3, 8):
        print("✗ Python 3.8+ is required")
        return False
    return True

def check_pip():
    """Check pip installation"""
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "--version"], 
                              capture_output=True, text=True)
        print("✓ Pip Version:", result.stdout.split()[1])
        return True
    except:
        print("✗ Pip not found")
        return False

def check_requirements():
    """Check if required packages are installed"""
    required_packages = [
        'flask',
        'flask_cors',
        'google.generativeai',
        'pillow',
        'python-dotenv'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} NOT installed")
            missing.append(package)
    
    if missing:
        print(f"\n⚠ Missing packages: {', '.join(missing)}")
        print("Run: pip install -r requirements.txt")
        return False
    return True

def check_env_file():
    """Check if .env file exists and has API key"""
    backend_path = os.path.join(os.path.dirname(__file__), 'backend', '.env')
    
    if not os.path.exists(backend_path):
        print(f"✗ .env file not found at {backend_path}")
        print("  Create it from .env.example")
        return False
    
    try:
        with open(backend_path, 'r') as f:
            content = f.read()
            if 'GEMINI_API_KEY' in content and 'your_gemini_api_key_here' not in content:
                print("✓ .env file exists with API key configured")
                return True
            else:
                print("✗ .env file missing or invalid API key")
                print("  Edit backend/.env and add your Gemini API key")
                return False
    except Exception as e:
        print(f"✗ Error reading .env: {e}")
        return False

def check_directories():
    """Check if required directories exist"""
    dirs = [
        'backend',
        'backend/uploads',
        'frontend',
        'frontend/templates',
        'frontend/static',
        'frontend/static/css',
        'frontend/static/js'
    ]
    
    all_exist = True
    for dir_path in dirs:
        full_path = os.path.join(os.path.dirname(__file__), dir_path)
        if os.path.exists(full_path):
            print(f"✓ {dir_path}")
        else:
            print(f"✗ {dir_path} NOT found")
            all_exist = False
    
    return all_exist

def check_files():
    """Check if required files exist"""
    files = [
        'backend/app.py',
        'backend/config.py',
        'backend/utils.py',
        'frontend/app.py',
        'frontend/templates/index.html',
        'frontend/static/css/style.css',
        'frontend/static/js/script.js',
        'requirements.txt',
        'README.md'
    ]
    
    all_exist = True
    for file_path in files:
        full_path = os.path.join(os.path.dirname(__file__), file_path)
        if os.path.exists(full_path):
            size = os.path.getsize(full_path) / 1024  # Size in KB
            print(f"✓ {file_path} ({size:.1f} KB)")
        else:
            print(f"✗ {file_path} NOT found")
            all_exist = False
    
    return all_exist

def main():
    print_header("AI Fashion Stylist - Installation Verification")
    
    checks = [
        ("Python Installation", check_python),
        ("Pip Installation", check_pip),
        ("Project Directories", check_directories),
        ("Project Files", check_files),
        ("Required Python Packages", check_requirements),
        ("Environment Configuration", check_env_file)
    ]
    
    results = []
    for name, check_func in checks:
        print_header(name)
        try:
            result = check_func()
            results.append((name, result))
        except Exception as e:
            print(f"✗ Error: {e}")
            results.append((name, False))
    
    # Summary
    print_header("SUMMARY")
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status}: {name}")
    
    print(f"\nTotal: {passed}/{total} checks passed\n")
    
    if passed == total:
        print("🎉 All checks passed! Ready to run!")
        print("\nNext steps:")
        print("1. Make sure your Gemini API key is in backend/.env")
        print("2. Run: cd backend && python app.py")
        print("3. In another terminal: cd frontend && python app.py")
        print("4. Open: http://localhost:3000")
        return 0
    else:
        print("⚠ Some checks failed. Please review the errors above.")
        print("\nCommon fixes:")
        print("- Run: pip install -r requirements.txt")
        print("- Create backend/.env from backend/.env.example")
        print("- Add your Gemini API key to backend/.env")
        return 1

if __name__ == "__main__":
    sys.exit(main())
