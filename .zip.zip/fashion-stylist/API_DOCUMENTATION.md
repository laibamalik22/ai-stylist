# AI Fashion Stylist - API Documentation

## Base URL
```
http://localhost:5000/api
```

## Endpoints

### 1. Health Check
Check if the backend is running

**Request:**
```
GET /api/health
```

**Response:**
```json
{
  "status": "ok",
  "message": "Fashion Stylist API is running"
}
```

---

### 2. Get Outfit Recommendations
Generate personalized outfit recommendations

**Request:**
```
POST /api/recommend
Content-Type: application/json

{
  "gender": "female",
  "event": "casual",
  "weather": "sunny",
  "preferences": "minimalist, earth tones, sustainable fashion"
}
```

**Parameters:**
- `gender` (string, required): "male", "female", or "unisex"
- `event` (string, required): "casual", "office", "formal", "party", "gym", "date", "wedding", "travel", "weekend", "beach"
- `weather` (string, required): "sunny", "rainy", "cold", "mild", "hot", "windy"
- `preferences` (string, required): Your style preferences

**Response:**
```json
{
  "outfits": [
    {
      "outfit_number": 1,
      "top": "Linen white button-up shirt",
      "bottom": "Khaki linen pants",
      "shoes": "White canvas sneakers",
      "accessories": ["Woven belt", "Straw hat", "Canvas tote bag"],
      "vibe": "Effortless minimalist chic",
      "why_it_works": "Perfect for casual summer days with sustainable, natural fabrics"
    },
    ...
  ]
}
```

---

### 3. Analyze Outfit Image
Upload an outfit photo and get styling suggestions

**Request:**
```
POST /api/analyze-outfit
Content-Type: multipart/form-data

Parameters:
- image: <file>
- preferences: "How can I make this more professional?"
```

**Response:**
```json
{
  "analysis": "You're wearing a casual black t-shirt with jeans...",
  "improvements": "You could elevate this by adding...",
  "alternatives": [
    {
      "option": 1,
      "description": "Pair with a blazer for a business casual look"
    }
  ],
  "accessories": ["Watch", "Statement necklace", "Loafers"],
  "suitable_occasions": ["Casual brunch", "Shopping", "Coffee date"]
}
```

---

### 4. Chat with Stylist
Get fashion advice through conversational AI

**Request:**
```
POST /api/chat
Content-Type: application/json

{
  "message": "How do I style a white shirt?"
}
```

**Response:**
```json
{
  "response": "A white shirt is incredibly versatile! You can wear it...",
  "timestamp": "2024-04-29T10:30:45.123456"
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Missing required fields"
}
```

### 400 File Upload Error
```json
{
  "error": "File type not allowed"
}
```

### 500 Server Error
```json
{
  "error": "Internal server error message"
}
```

---

## Example Usage

### Using cURL

```bash
# Get recommendations
curl -X POST http://localhost:5000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{
    "gender": "female",
    "event": "office",
    "weather": "mild",
    "preferences": "professional, classic style"
  }'

# Chat
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What colors go well with blue?"
  }'
```

### Using Python

```python
import requests

# Get recommendations
response = requests.post(
    'http://localhost:5000/api/recommend',
    json={
        'gender': 'male',
        'event': 'date',
        'weather': 'cold',
        'preferences': 'trendy, comfortable'
    }
)
print(response.json())

# Upload and analyze outfit
with open('outfit.jpg', 'rb') as f:
    files = {'image': f}
    data = {'preferences': 'Make it more formal'}
    response = requests.post(
        'http://localhost:5000/api/analyze-outfit',
        files=files,
        data=data
    )
print(response.json())
```

### Using JavaScript/Fetch

```javascript
// Get recommendations
fetch('http://localhost:5000/api/recommend', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    gender: 'female',
    event: 'party',
    weather: 'warm',
    preferences: 'glamorous, bold colors'
  })
})
.then(res => res.json())
.then(data => console.log(data))
```

---

## Rate Limiting

The API is limited by the Google Gemini API quotas. Check your usage at:
https://makersuite.google.com/app/apikey

---

## Testing the API

### Using Postman

1. Import the requests into Postman
2. Set base URL to `http://localhost:5000`
3. Create requests for each endpoint

### Using VS Code REST Client

Create a file `test.http`:

```http
### Health Check
GET http://localhost:5000/api/health

### Get Recommendations
POST http://localhost:5000/api/recommend
Content-Type: application/json

{
  "gender": "female",
  "event": "casual",
  "weather": "sunny",
  "preferences": "bohemian, colorful"
}

### Chat
POST http://localhost:5000/api/chat
Content-Type: application/json

{
  "message": "How do I dress for an interview?"
}
```

---

## CORS Configuration

The API allows cross-origin requests from:
- `http://localhost:3000`
- `http://127.0.0.1:3000`

For production, update the allowed origins in `backend/app.py`

---

## Troubleshooting API Issues

### 401 Unauthorized (API Key Error)
- Check `.env` file contains valid Gemini API key
- Verify API key has not expired

### 503 Service Unavailable
- Google Gemini API may be down
- Check API status at https://status.cloud.google.com

### Slow Responses
- First request may be slower due to model loading
- Check internet connection
- Verify API key has usage quota remaining

---

## API Status

Monitor API health:
```bash
curl http://localhost:5000/api/health
```

---

For more information, see the main README.md file.
