// Configuration
const API_BASE_URL = 'http://localhost:5000/api';

// DOM Elements
const styleForm = document.getElementById('styleForm');
const uploadForm = document.getElementById('uploadForm');
const chatForm = document.getElementById('chatForm');
const uploadArea = document.getElementById('uploadArea');
const outfitImage = document.getElementById('outfitImage');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const removeImageBtn = document.getElementById('removeImage');
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
const chatBox = document.getElementById('chatBox');
const chatInput = document.getElementById('chatInput');
const recommendationsContainer = document.getElementById('recommendationsContainer');
const loadingSpinner = document.getElementById('loadingSpinner');
const analysisContainer = document.getElementById('analysisContainer');
const loadingSpinnerAnalysis = document.getElementById('loadingSpinnerAnalysis');

// Tab Switching
tabBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        const tabName = btn.dataset.tab;
        
        // Remove active class from all buttons and contents
        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(tc => tc.classList.remove('active'));
        
        // Add active class to clicked button and corresponding content
        btn.classList.add('active');
        document.getElementById(tabName).classList.add('active');
    });
});

// ==================== STYLE RECOMMENDATIONS ====================
styleForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const gender = document.getElementById('gender').value;
    const event = document.getElementById('event').value;
    const weather = document.getElementById('weather').value;
    const preferences = document.getElementById('preferences').value;
    
    if (!gender || !event || !weather || !preferences) {
        showError('Please fill in all fields');
        return;
    }
    
    showLoadingSpinner('recommendations');
    
    try {
        const response = await fetch(`${API_BASE_URL}/recommend`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                gender,
                event,
                weather,
                preferences
            })
        });
        
        const data = await response.json();
        displayRecommendations(data);
        hideLoadingSpinner('recommendations');
    } catch (error) {
        console.error('Error:', error);
        showError('Failed to get recommendations. Please try again.');
        hideLoadingSpinner('recommendations');
    }
});

function displayRecommendations(data) {
    const container = document.getElementById('recommendations');
    container.innerHTML = '';
    
    if (data.error) {
        container.innerHTML = `<div class="error-message">Error: ${data.error}</div>`;
        return;
    }
    
    if (data.outfits && data.outfits.length > 0) {
        data.outfits.forEach((outfit, index) => {
            const outfitHTML = `
                <div class="outfit-card">
                    <h3>Outfit ${outfit.outfit_number || index + 1}</h3>
                    
                    <div class="outfit-item">
                        <strong>👕 Top:</strong>
                        ${outfit.top}
                    </div>
                    
                    <div class="outfit-item">
                        <strong>👖 Bottom:</strong>
                        ${outfit.bottom}
                    </div>
                    
                    <div class="outfit-item">
                        <strong>👞 Shoes:</strong>
                        ${outfit.shoes}
                    </div>
                    
                    <div class="outfit-item">
                        <strong>✨ Accessories:</strong>
                        <ul class="accessories-list">
                            ${outfit.accessories.map(acc => `<li>${acc}</li>`).join('')}
                        </ul>
                    </div>
                    
                    <div class="outfit-item">
                        <strong>💫 Vibe:</strong>
                        ${outfit.vibe}
                        <span class="vibe-badge">${outfit.vibe}</span>
                    </div>
                    
                    <div class="outfit-item">
                        <strong>💡 Why It Works:</strong>
                        ${outfit.why_it_works}
                    </div>
                </div>
            `;
            container.innerHTML += outfitHTML;
        });
    } else {
        container.innerHTML = '<div class="error-message">No recommendations available</div>';
    }
}

// ==================== OUTFIT UPLOAD & ANALYSIS ====================
uploadArea.addEventListener('click', () => outfitImage.click());

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.opacity = '0.7';
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.opacity = '1';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.opacity = '1';
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleImageSelect(files[0]);
    }
});

outfitImage.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleImageSelect(e.target.files[0]);
    }
});

function handleImageSelect(file) {
    if (!file.type.startsWith('image/')) {
        showError('Please select an image file');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        imagePreview.classList.remove('hidden');
        uploadArea.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

removeImageBtn.addEventListener('click', () => {
    outfitImage.value = '';
    imagePreview.classList.add('hidden');
    uploadArea.style.display = 'block';
});

uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!outfitImage.files.length) {
        showError('Please select an image');
        return;
    }
    
    const formData = new FormData();
    formData.append('image', outfitImage.files[0]);
    formData.append('preferences', document.getElementById('uploadPreferences').value || 'general styling advice');
    
    showLoadingSpinner('analysis');
    
    try {
        const response = await fetch(`${API_BASE_URL}/analyze-outfit`, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        displayAnalysis(data);
        hideLoadingSpinner('analysis');
    } catch (error) {
        console.error('Error:', error);
        showError('Failed to analyze outfit. Please try again.');
        hideLoadingSpinner('analysis');
    }
});

function displayAnalysis(data) {
    const container = document.getElementById('analysis');
    container.innerHTML = '';
    
    if (data.error) {
        container.innerHTML = `<div class="error-message">Error: ${data.error}</div>`;
        return;
    }
    
    let analysisHTML = '';
    
    if (data.analysis) {
        analysisHTML += `
            <div class="analysis-section">
                <h3>📸 Current Outfit Analysis</h3>
                <p>${data.analysis}</p>
            </div>
        `;
    }
    
    if (data.improvements) {
        analysisHTML += `
            <div class="analysis-section">
                <h3>✨ How to Improve</h3>
                <p>${data.improvements}</p>
            </div>
        `;
    }
    
    if (data.accessories && data.accessories.length > 0) {
        analysisHTML += `
            <div class="analysis-section">
                <h3>💎 Accessory Recommendations</h3>
                <ul class="accessories-list">
                    ${data.accessories.map(acc => `<li>${acc}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    if (data.suitable_occasions && data.suitable_occasions.length > 0) {
        analysisHTML += `
            <div class="analysis-section">
                <h3>🎯 Suitable Occasions</h3>
                <ul class="accessories-list">
                    ${data.suitable_occasions.map(occ => `<li>${occ}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    if (data.alternatives && data.alternatives.length > 0) {
        analysisHTML += `
            <div class="analysis-section">
                <h3>🔄 Alternative Outfit Combinations</h3>
        `;
        data.alternatives.forEach(alt => {
            analysisHTML += `
                <div style="padding: 10px; background: white; margin: 10px 0; border-radius: 6px;">
                    <strong>Option ${alt.option}:</strong> ${alt.description}
                </div>
            `;
        });
        analysisHTML += '</div>';
    }
    
    container.innerHTML = analysisHTML || '<div class="error-message">No analysis available</div>';
}

// ==================== CHAT ====================
chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Add user message to chat
    addChatMessage(message, 'user');
    chatInput.value = '';
    
    try {
        const response = await fetch(`${API_BASE_URL}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        if (data.response) {
            addChatMessage(data.response, 'assistant');
        } else if (data.error) {
            addChatMessage('Sorry, I encountered an error: ' + data.error, 'assistant');
        }
    } catch (error) {
        console.error('Error:', error);
        addChatMessage('Sorry, I couldn\'t process your request. Please try again.', 'assistant');
    }
});

function addChatMessage(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${sender}`;
    
    // Simple markdown support
    let formattedMessage = message
        .replace(/\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    messageDiv.innerHTML = `<p>${formattedMessage}</p>`;
    chatBox.appendChild(messageDiv);
    
    // Scroll to bottom
    setTimeout(() => {
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 0);
}

// ==================== UTILITY FUNCTIONS ====================
function showLoadingSpinner(type) {
    if (type === 'recommendations') {
        recommendationsContainer.classList.remove('hidden');
        loadingSpinner.classList.remove('hidden');
    } else if (type === 'analysis') {
        analysisContainer.classList.remove('hidden');
        loadingSpinnerAnalysis.classList.remove('hidden');
    }
}

function hideLoadingSpinner(type) {
    if (type === 'recommendations') {
        loadingSpinner.classList.add('hidden');
    } else if (type === 'analysis') {
        loadingSpinnerAnalysis.classList.add('hidden');
    }
}

function showError(message) {
    console.error(message);
    alert(message);
}

// Initialize chat with greeting on page load
window.addEventListener('load', () => {
    console.log('Fashion Stylist chatbot loaded');
});
