# 👗 AI Fashion Stylist Chatbot

A complete AI-powered fashion styling application with Python backend and modern web frontend. Get personalized outfit recommendations, analyze your existing clothes, and chat with your AI stylist!

## 🌟 Features

- **Smart Outfit Recommendations**: Get 3 complete outfit suggestions based on gender, occasion, weather, and style preferences
- **Outfit Analysis**: Upload a photo of your outfit and get AI-powered styling suggestions
- **Interactive Chat**: Ask your AI stylist any fashion-related questions
- **Beautiful UI**: Modern, responsive design that works on desktop and mobile
- **Powered by Google Gemini AI**: Advanced AI models for intelligent recommendations

## 📋 Requirements

- Python 3.8+
- Google Gemini API Key (get it free from [makersuite.google.com](https://makersuite.google.com/app/apikey))
- 2GB RAM minimum
- Internet connection

## 🚀 Quick Start

### 1. Get Your Google Gemini API Key

1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Click "Create API key"
3. Copy your API key
4. Keep it safe - you'll need it in Step 4

### 2. Install Python Dependencies

Open PowerShell in the `fashion-stylist` directory and run:

```powershell
# Create virtual environment (optional but recommended)
python -m venv venv
.\venv\Scripts\Activate.ps1

# Install all required packages
pip install -r requirements.txt
```

### 3. Set Up Environment Variables

1. Navigate to the `backend` folder
2. Copy `.env.example` to `.env`
3. Open `.env` and paste your Gemini API key:
   ```
   GEMINI_API_KEY=your_api_key_here
   ```

### 4. Run the Application

#### Method 1: Using Two Terminals (Recommended)

**Terminal 1 - Backend Server:**
```powershell
cd backend
python app.py
```
The backend will start at `http://localhost:5000`

**Terminal 2 - Frontend Server:**
```powershell
cd frontend
python app.py
```
The frontend will start at `http://localhost:3000`

#### Method 2: Using Run Script

If you prefer an automated setup, run:
```powershell
# (If we create a batch script)
```

### 5. Access the Application

Open your browser and go to:
```
http://localhost:3000
```

## 📱 How to Use

### Style Recommendations Tab
1. Select your gender/style preference
2. Choose an occasion (casual, office, party, etc.)
3. Select current weather conditions
4. Describe your style preferences
5. Click "Get Recommendations" to receive 3 complete outfits

### Analyze My Outfit Tab
1. Upload a photo of your current outfit
2. (Optional) Add specific improvement questions
3. Click "Analyze Outfit" to get styling suggestions
4. Receive analysis, improvement tips, and accessory recommendations

### Ask Stylist Tab
1. Type any fashion-related question
2. Get instant responses from your AI stylist
3. Ask follow-up questions for more specific advice

## 🔧 Configuration

### Backend Settings (`.env`)
```
GEMINI_API_KEY=your_api_key_here
FLASK_ENV=development
FLASK_DEBUG=True
MAX_FILE_SIZE=10485760  # 10MB in bytes
UPLOAD_FOLDER=uploads
```

### Port Configuration
- Backend API: Port 5000 (change in `backend/app.py`)
- Frontend: Port 3000 (change in `frontend/app.py`)

## 📊 API Endpoints

### Backend API (http://localhost:5000)

#### Health Check
```
GET /api/health
```

#### Get Outfit Recommendations
```
POST /api/recommend
Content-Type: application/json

{
  "gender": "female",
  "event": "casual",
  "weather": "sunny",
  "preferences": "minimalist, earth tones"
}
```

#### Analyze Outfit Image
```
POST /api/analyze-outfit
Content-Type: multipart/form-data

Parameters:
- image: <image_file>
- preferences: <optional_styling_questions>
```

#### Chat with Stylist
```
POST /api/chat
Content-Type: application/json

{
  "message": "How do I style a white shirt?"
}
```

## 🎨 Customization

### Change Colors
Edit `frontend/static/css/style.css` and modify the CSS variables:
```css
:root {
    --primary-color: #9c27b0;
    --secondary-color: #ff6b9d;
    /* ... other colors ... */
}
```

### Add More Occasions
Edit `frontend/templates/index.html` in the event select:
```html
<option value="your_occasion">Your Occasion</option>
```

## 🐛 Troubleshooting

### "Invalid API Key" Error
- Check your `.env` file in the backend folder
- Verify your Gemini API key is correct
- Make sure the `.env` file is in `backend/` directory

### "Connection refused" Error
- Make sure backend is running on port 5000
- Make sure frontend is running on port 3000
- Check firewall settings

### Image Upload Issues
- Ensure image is under 10MB
- Supported formats: PNG, JPG, JPEG, GIF, WEBP
- Check upload folder has write permissions

### Frontend Not Loading
- Clear browser cache (Ctrl+Shift+Delete)
- Try a different browser
- Check browser console for errors (F12)

## 📚 Technology Stack

**Backend:**
- Flask 2.3.3 - Web framework
- Google Generative AI - AI recommendations
- Pillow - Image processing
- Flask-CORS - Cross-origin requests

**Frontend:**
- HTML5 - Structure
- CSS3 - Styling with gradients and animations
- Vanilla JavaScript - Interactivity
- Fetch API - HTTP requests

## 📝 File Structure

```
fashion-stylist/
├── backend/
│   ├── app.py                 # Backend Flask app
│   ├── uploads/               # Uploaded images storage
│   └── .env                   # API configuration
├── frontend/
│   ├── app.py                 # Frontend Flask app
│   ├── templates/
│   │   └── index.html         # Main UI
│   └── static/
│       ├── css/
│       │   └── style.css      # Styling
│       └── js/
│           └── script.js      # Frontend logic
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

## 🚨 Important Notes

1. **API Key Security**: Never share your Gemini API key publicly or commit it to version control
2. **Rate Limiting**: Google Gemini API has usage limits - check your quota
3. **Data Privacy**: Images uploaded are temporarily stored and deleted after analysis
4. **CORS**: Frontend runs on port 3000, backend on 5000 - CORS is enabled for this configuration

## 🤝 Contributing

This is a personal project. Feel free to modify and extend it for your needs!

## ❓ FAQ

**Q: Can I change the ports?**
A: Yes! Edit the `port=5000` in `backend/app.py` and `port=3000` in `frontend/app.py`

**Q: How many requests can I make?**
A: Check your Gemini API quota at [makersuite.google.com](https://makersuite.google.com)

**Q: Can I deploy this to production?**
A: Yes, but change `debug=True` to `debug=False` and use a production WSGI server like Gunicorn

**Q: Does it work on mobile?**
A: Yes! The UI is fully responsive

## 📧 Support

For issues with:
- **Gemini API**: Visit [Google AI Forum](https://ai.google.dev)
- **Flask**: Check [Flask Documentation](https://flask.palletsprojects.com)
- **This app**: Review the troubleshooting section above

## 📄 License

This project is provided as-is for educational and personal use.

---

**Enjoy your AI Fashion Stylist! 👗✨**

Made with ❤️ using Google Gemini AI
