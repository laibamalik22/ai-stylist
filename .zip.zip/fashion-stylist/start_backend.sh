#!/bin/bash
# Fashion Stylist - Backend Startup Script for macOS/Linux

cd "$(dirname "$0")"
cd backend

echo "Starting Backend Server on http://localhost:5000..."
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

python app.py
