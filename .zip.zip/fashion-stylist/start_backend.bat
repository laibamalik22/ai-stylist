@echo off
REM Start Backend Server

cd backend
echo Starting Backend Server on http://localhost:5000...
echo.
echo Press Ctrl+C to stop the server
echo.
python app.py
pause
