# Fashion Stylist - Quick Start Guide

## ⚡ 5-Minute Setup

### Prerequisites
- Python 3.8+ installed
- Free Gemini API key from https://makersuite.google.com/app/apikey

### Steps

#### 1. Get API Key (2 minutes)
```
Visit: https://makersuite.google.com/app/apikey
Click: "Create API key"
Copy: Your API key
```

#### 2. Configure API Key (1 minute)
```powershell
# Open backend\.env
notepad backend\.env

# Replace:
GEMINI_API_KEY=your_gemini_api_key_here

# With your actual key from Step 1
# Save and close
```

#### 3. Install & Run (2 minutes)
```powershell
# First Terminal - Install dependencies
pip install -r requirements.txt

# First Terminal - Start Backend
cd backend
python app.py

# ✓ Wait for: "Running on http://127.0.0.1:5000"
```

```powershell
# Second Terminal - Start Frontend
cd frontend
python app.py

# ✓ Wait for: "Running on http://127.0.0.1:3000"
```

#### 4. Open Browser
```
Visit: http://localhost:3000
Enjoy! 🎉
```

---

## 🎯 Features to Try

### 1. Get Outfit Recommendations
- Fill form with your preferences
- Get 3 complete outfits with styling details

### 2. Analyze Your Outfit
- Upload a photo of your current outfit
- Get AI-powered suggestions for improvement

### 3. Chat with Stylist
- Ask any fashion-related questions
- Get instant expert advice

---

## 📁 Project Structure

```
fashion-stylist/
├── backend/
│   ├── app.py              ← Main backend server
│   ├── config.py           ← Configuration
│   ├── utils.py            ← Helper functions
│   ├── uploads/            ← Temporary image storage
│   └── .env                ← Your API key (create this)
├── frontend/
│   ├── app.py              ← Frontend server
│   ├── templates/
│   │   └── index.html      ← Main web interface
│   └── static/
│       ├── css/style.css   ← Styling
│       └── js/script.js    ← Interactions
├── requirements.txt        ← Python dependencies
├── setup.bat               ← Automated setup (Windows)
├── start_backend.bat       ← Start backend (Windows)
├── start_frontend.bat      ← Start frontend (Windows)
└── README.md              ← Full documentation
```

---

## 🆘 Quick Troubleshooting

### "Invalid API key"
→ Check `.env` file has your real API key

### "Connection refused"
→ Make sure both backend and frontend are running

### "Module not found"
→ Run: `pip install -r requirements.txt`

### "Port already in use"
→ Change port in app.py files or close other apps using those ports

---

## 📞 More Help

- Full Guide: See `README.md`
- Detailed Setup: See `SETUP_GUIDE.md`
- Troubleshooting: See bottom of README.md

---

**Enjoy your AI Fashion Stylist! 👗✨**
