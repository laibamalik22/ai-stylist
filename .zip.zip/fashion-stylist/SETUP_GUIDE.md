# 🎯 Complete Setup Guide for AI Fashion Stylist

## Step 1: Get Your Free API Key ✨

### Option A: Free Gemini API (Recommended)

1. Open your browser and go to: https://makersuite.google.com/app/apikey
2. Sign in with your Google account (create one if needed)
3. Click the blue **"Create API key"** button
4. Choose "Create API key in new project"
5. Your API key will be displayed - **COPY IT** (it looks like: `AIzaSyD...`)
6. Keep it safe - you'll need it in the next steps

### Option B: Using Your Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable the "Google Generative AI API"
4. Create an API key in "Credentials"
5. Copy your API key

## Step 2: Install Python 🐍

### Check if Python is Already Installed:
```powershell
python --version
```

If you see a version number (3.8 or higher), you have Python installed. Skip to Step 3.

### If Python is NOT installed:
1. Go to https://www.python.org/downloads/
2. Download Python 3.11 (or latest stable version)
3. Run the installer
4. **IMPORTANT**: Check the box "Add Python to PATH"
5. Click "Install Now"
6. Wait for installation to complete

### Verify Installation:
```powershell
python --version
pip --version
```

Both should show version numbers.

## Step 3: Set Up the Project 📁

### Extract/Navigate to Project:

```powershell
# Navigate to the fashion-stylist folder
cd C:\Users\admin\New folder\fashion-stylist

# List files to verify
ls
```

You should see:
- `backend/` folder
- `frontend/` folder
- `requirements.txt` file
- `README.md` file

### Create Virtual Environment (Optional but Recommended):

```powershell
# Create virtual environment
python -m venv venv

# Activate it
.\venv\Scripts\Activate.ps1
```

If you see `(venv)` at the start of your terminal line, activation was successful!

### Install Dependencies:

```powershell
# Make sure you're in the fashion-stylist directory
pip install -r requirements.txt
```

This will install:
- Flask (web server)
- Flask-CORS (cross-origin support)
- Google Generative AI (Gemini API)
- Pillow (image processing)
- And other dependencies

Wait for all packages to install (may take 2-5 minutes).

## Step 4: Configure API Key 🔑

### Backend Configuration:

1. Navigate to the backend folder:
```powershell
cd backend
```

2. You should see a file called `.env.example`. Make a copy:
```powershell
# Copy .env.example to .env
Copy-Item .env.example .env
```

3. Open the `.env` file with a text editor:
```powershell
# Open with Notepad
notepad .env
```

4. Find this line:
```
GEMINI_API_KEY=your_gemini_api_key_here
```

5. Replace `your_gemini_api_key_here` with your actual API key from Step 1:
```
GEMINI_API_KEY=AIzaSyD... (your actual key)
```

6. Save the file (Ctrl+S) and close

7. Go back to the main folder:
```powershell
cd ..
```

## Step 5: Run the Application 🚀

### Important: You need TWO PowerShell windows open

### Window 1: Start the Backend

```powershell
# Make sure you're in fashion-stylist directory
cd backend

# Run the backend
python app.py
```

You should see:
```
* Running on http://127.0.0.1:5000
```

**Keep this window open!** Don't close it.

### Window 2: Start the Frontend

Open a **NEW** PowerShell window and:

```powershell
# Navigate to fashion-stylist\frontend
cd fashion-stylist\frontend

# Run the frontend
python app.py
```

You should see:
```
* Running on http://127.0.0.1:3000
```

**Keep this window open too!**

## Step 6: Access the Application 🌐

### Open Your Browser:

1. Open any web browser (Chrome, Firefox, Edge, etc.)
2. Type this in the address bar:
```
http://localhost:3000
```

3. Press Enter

You should see the **AI Fashion Stylist** home page!

## 🎉 Success! Now What?

### Try These Features:

1. **Get Outfit Recommendations**
   - Fill in: Gender/Style, Occasion, Weather, Preferences
   - Click "Get Recommendations"
   - You'll get 3 complete outfit ideas!

2. **Analyze Your Outfit**
   - Upload a photo of your current outfit
   - Add what you want to improve
   - Click "Analyze Outfit"
   - Get AI suggestions!

3. **Chat with Your Stylist**
   - Ask any fashion questions
   - Get instant answers!

## 🆘 Troubleshooting

### Problem: "ModuleNotFoundError" when running app.py

**Solution:**
```powershell
# Make sure virtual environment is activated
.\venv\Scripts\Activate.ps1

# Install requirements again
pip install -r requirements.txt

# Try running app.py again
python app.py
```

### Problem: "Invalid API Key" error

**Solution:**
1. Go back to Step 1 and verify your API key
2. Check that `.env` file is in the `backend/` folder
3. Make sure `.env` has the correct key with no extra spaces:
   ```
   GEMINI_API_KEY=AIzaSyD... (exactly as provided, no quotes)
   ```
4. Restart the backend (close and reopen the terminal)

### Problem: Frontend shows "Connection refused"

**Solution:**
1. Make sure backend is running (Window 1 shows "Running on http://127.0.0.1:5000")
2. Make sure frontend is running (Window 2 shows "Running on http://127.0.0.1:3000")
3. Refresh the browser (F5 or Ctrl+R)
4. Check that firewall isn't blocking ports 5000 and 3000

### Problem: Browser shows blank page

**Solution:**
1. Clear browser cache: Ctrl+Shift+Delete
2. Hard refresh: Ctrl+Shift+R
3. Open browser developer tools: F12
4. Check the "Console" tab for errors
5. Try a different browser

### Problem: Image upload not working

**Solution:**
1. Make sure image is under 10MB
2. Use formats: JPG, PNG, GIF, or WEBP
3. Check `backend/uploads/` folder exists
4. Ensure file permissions allow writing

### Problem: Slow responses

**Solution:**
1. Check internet connection
2. Verify API key has usage remaining
3. Wait a moment - first request may be slower
4. Try a simpler question/request

## 📊 Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| `Connection refused` | Backend not running | Run `python app.py` in backend folder |
| `No API key` | .env not found/configured | Create .env file with your API key |
| `Port already in use` | Port 5000 or 3000 in use | Change port in app.py |
| `Module not found` | Dependencies not installed | Run `pip install -r requirements.txt` |
| `Blank page` | Frontend not loading | Clear cache and refresh browser |

## 🔧 Advanced: Changing Ports

### If port 5000 or 3000 are already in use:

**Backend (change from 5000):**
1. Open `backend/app.py`
2. Find: `app.run(debug=True, host='0.0.0.0', port=5000)`
3. Change to: `app.run(debug=True, host='0.0.0.0', port=8000)`
4. Restart backend

**Frontend (change from 3000):**
1. Open `frontend/app.py`
2. Find: `app.run(debug=True, host='0.0.0.0', port=3000)`
3. Change to: `app.run(debug=True, host='0.0.0.0', port=8080)`
4. Update frontend config in `frontend/static/js/script.js`:
   - Change `const API_BASE_URL = 'http://localhost:5000/api'` to your new backend port
5. Restart frontend

Then access at: `http://localhost:8080` (or your new port)

## ✅ Checklist

Before running, make sure you have:

- [ ] Python 3.8+ installed and accessible
- [ ] Gemini API key from makersuite.google.com
- [ ] .env file created in backend folder with API key
- [ ] All dependencies installed (`pip install -r requirements.txt`)
- [ ] Backend running on port 5000 (in one PowerShell window)
- [ ] Frontend running on port 3000 (in another PowerShell window)
- [ ] Browser accessing http://localhost:3000

## 🎓 Learning Resources

- **Flask Docs**: https://flask.palletsprojects.com
- **Google Gemini API**: https://ai.google.dev
- **Python Docs**: https://docs.python.org/3

## 🎉 You're All Set!

Enjoy your AI Fashion Stylist! 

**Need help?** Check the troubleshooting section or review the README.md file.

---

**Happy styling! 👗✨**
