#!/bin/bash
# Fashion Stylist - Frontend Startup Script for macOS/Linux

cd "$(dirname "$0")"
cd frontend

echo "Starting Frontend Server on http://localhost:3000..."
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

python app.py
