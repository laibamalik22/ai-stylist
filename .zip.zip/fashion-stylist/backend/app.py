from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
import warnings
# Suppress the deprecation warning for now - using google.generativeai
with warnings.catch_warnings():
    warnings.filterwarnings('ignore', category=FutureWarning)
    import google.generativeai as genai
from werkzeug.utils import secure_filename
from PIL import Image
import io
import base64
import json
from datetime import datetime

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize Gemini API
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'your-api-key-here')
genai.configure(api_key=GEMINI_API_KEY)

def allowed_file(filename):
    """Check if file has allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def encode_image_to_base64(image_path):
    """Convert image to base64 for API"""
    with open(image_path, 'rb') as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def generate_outfit_recommendations(gender, event, weather, preferences, outfit_image=None):
    """Generate outfit recommendations using Gemini API"""
    
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Build the prompt
        prompt = f"""You are a professional fashion stylist AI. Based on the following preferences, provide 3 complete outfit recommendations.

Gender: {gender}
Event: {event}
Weather: {weather}
Style Preferences: {preferences}

For each outfit, provide:
1. Top (with color and style details)
2. Bottom (with color and style details)
3. Shoes (with type and color)
4. Accessories (list 2-3 items)
5. Overall vibe/description
6. Why this outfit works for the occasion

Please format your response as JSON with the following structure:
{{
    "outfits": [
        {{
            "outfit_number": 1,
            "top": "description",
            "bottom": "description",
            "shoes": "description",
            "accessories": ["item1", "item2", "item3"],
            "vibe": "overall description",
            "why_it_works": "explanation"
        }}
    ]
}}

Provide exactly 3 complete outfits."""

        # Generate content
        response = model.generate_content(prompt)
        
        # Parse JSON response
        response_text = response.text
        
        # Extract JSON from response
        try:
            # Try to find JSON in the response
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            if start_idx != -1 and end_idx > start_idx:
                json_str = response_text[start_idx:end_idx]
                recommendations = json.loads(json_str)
            else:
                recommendations = {"outfits": [], "error": "Could not parse recommendations"}
        except json.JSONDecodeError:
            recommendations = {"outfits": [], "error": "Invalid JSON format", "raw_response": response_text}
        
        return recommendations
    
    except Exception as e:
        return {"outfits": [], "error": str(e)}

def analyze_outfit_image(image_path, preferences):
    """Analyze uploaded outfit image and provide recommendations"""
    
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Read image file
        with open(image_path, 'rb') as img_file:
            image_data = img_file.read()
        
        # Prepare image for API
        image_part = {
            "mime_type": "image/jpeg",
            "data": base64.standard_b64encode(image_data).decode("utf-8")
        }
        
        prompt = f"""Analyze this outfit image and provide styling suggestions based on the following preferences:
{preferences}

Please provide:
1. Current outfit analysis (what you see)
2. How to improve this outfit
3. 2 alternative outfit combinations using similar pieces
4. Accessories recommendations to elevate this outfit
5. Occasions this outfit is suitable for

Format your response as JSON:
{{
    "analysis": "what you see",
    "improvements": "suggestions",
    "alternatives": [
        {{
            "option": 1,
            "description": "outfit description"
        }}
    ],
    "accessories": ["item1", "item2"],
    "suitable_occasions": ["occasion1", "occasion2"]
}}"""

        response = model.generate_content([prompt, image_part])
        
        response_text = response.text
        
        try:
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            if start_idx != -1 and end_idx > start_idx:
                json_str = response_text[start_idx:end_idx]
                analysis = json.loads(json_str)
            else:
                analysis = {"error": "Could not parse analysis"}
        except json.JSONDecodeError:
            analysis = {"error": "Invalid JSON format", "raw_response": response_text}
        
        return analysis
    
    except Exception as e:
        return {"error": str(e)}

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "ok", "message": "Fashion Stylist API is running"}), 200

@app.route('/api/recommend', methods=['POST'])
def get_recommendations():
    """Generate outfit recommendations based on user preferences"""
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['gender', 'event', 'weather', 'preferences']
        if not all(field in data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400
        
        gender = data.get('gender')
        event = data.get('event')
        weather = data.get('weather')
        preferences = data.get('preferences')
        
        # Generate recommendations
        recommendations = generate_outfit_recommendations(gender, event, weather, preferences)
        
        return jsonify(recommendations), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/analyze-outfit', methods=['POST'])
def analyze_outfit():
    """Analyze uploaded outfit image and provide suggestions"""
    
    try:
        # Check if file is in request
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
        
        if not allowed_file(file.filename):
            return jsonify({"error": "File type not allowed"}), 400
        
        # Save uploaded file
        filename = secure_filename(f"{datetime.now().timestamp()}_{file.filename}")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Get preferences from form data
        preferences = request.form.get('preferences', 'general styling advice')
        
        # Analyze outfit
        analysis = analyze_outfit_image(filepath, preferences)
        
        # Clean up uploaded file
        try:
            os.remove(filepath)
        except:
            pass
        
        return jsonify(analysis), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    """Chat endpoint for conversational styling advice"""
    
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({"error": "Message is required"}), 400
        
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        prompt = f"""You are a friendly and knowledgeable fashion stylist AI assistant. Help the user with their fashion questions and styling advice.

User question: {user_message}

Provide helpful, practical fashion advice. If they ask for outfit recommendations, be specific about colors, styles, and occasions."""

        response = model.generate_content(prompt)
        
        return jsonify({
            "response": response.text,
            "timestamp": datetime.now().isoformat()
        }), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
