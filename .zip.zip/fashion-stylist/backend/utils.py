"""
Utility functions for the Fashion Stylist application
"""

import os
import json
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    """Check if file has allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_size_mb(file):
    """Get file size in MB"""
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    return size / (1024 * 1024)

def parse_json_safely(text):
    """Safely parse JSON from text, handling markdown code blocks"""
    try:
        # Try direct parsing first
        return json.loads(text)
    except json.JSONDecodeError:
        # Try to extract JSON from markdown code blocks
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        if start_idx != -1 and end_idx > start_idx:
            try:
                return json.loads(text[start_idx:end_idx])
            except json.JSONDecodeError:
                return None
        return None

def create_upload_dir(directory):
    """Create upload directory if it doesn't exist"""
    os.makedirs(directory, exist_ok=True)

def save_secure_filename(directory, original_filename, prefix=''):
    """Generate and return secure filename"""
    from datetime import datetime
    filename = secure_filename(f"{prefix}_{datetime.now().timestamp()}_{original_filename}")
    return os.path.join(directory, filename)

def format_error_response(message, status_code=400):
    """Format error response"""
    return {"error": message}, status_code

def format_success_response(data):
    """Format success response"""
    return {"success": True, **data}, 200

def truncate_text(text, max_length=500):
    """Truncate text to maximum length"""
    if len(text) > max_length:
        return text[:max_length] + "..."
    return text
