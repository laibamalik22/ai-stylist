@echo off
REM Fashion Stylist - Windows Startup Script

echo.
echo ============================================
echo   AI Fashion Stylist - Startup Script
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please download Python from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/4] Checking Python installation...
python --version
echo.

REM Check if virtual environment exists
if not exist "venv" (
    echo [2/4] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo Error: Failed to create virtual environment
        pause
        exit /b 1
    )
    echo Virtual environment created!
) else (
    echo [2/4] Virtual environment already exists
)
echo.

REM Activate virtual environment
echo [3/4] Activating virtual environment...
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo Error: Failed to activate virtual environment
    pause
    exit /b 1
)
echo.

REM Install requirements
echo [4/4] Installing dependencies...
pip install -r requirements.txt >nul 2>&1
if errorlevel 1 (
    echo Error: Failed to install dependencies
    pause
    exit /b 1
)
echo Dependencies installed!
echo.

echo ============================================
echo ✓ Setup Complete!
echo ============================================
echo.
echo Next steps:
echo 1. Configure your Gemini API key:
echo    - Open backend\.env with notepad
echo    - Add your API key
echo.
echo 2. Run the application:
echo    - Run "start_frontend.bat" in one terminal
echo    - Run "start_backend.bat" in another terminal
echo.
echo 3. Access the app at http://localhost:3000
echo.
pause
