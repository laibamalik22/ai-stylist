# 🚀 READY TO RUN - Complete Setup Guide

## ✅ Installation Status
- ✓ Python 3.14.4 installed
- ✓ Flask installed
- ✓ Flask-CORS installed  
- ✓ Python-dotenv installed
- ✓ Pillow installed
- ✓ Google Generative AI installed

**All packages are installed and ready!**

---

## 🎯 BEFORE YOU RUN THE APP

### Step 1: Get Your FREE Gemini API Key (2 minutes)

1. **Open your browser** and go to:
   ```
   https://makersuite.google.com/app/apikey
   ```

2. **Click "Create API key"**

3. **Copy the API key** that appears (looks like: `AIzaSyD...`)

4. **Keep it safe** - you'll need it in the next step

### Step 2: Configure Your API Key (1 minute)

1. **Open this file in your text editor:**
   ```
   C:\Users\admin\New folder\fashion-stylist\backend\.env
   ```

2. **Find this line:**
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```

3. **Replace** `your_gemini_api_key_here` with your actual API key from Step 1

4. **Save the file** (Ctrl+S)

---

## 🏃 NOW RUN THE APPLICATION

### Method 1: Using Batch Scripts (Easiest for Windows)

**Terminal 1:**
```powershell
# Navigate to project
cd "C:\Users\admin\New folder\fashion-stylist"

# Run backend startup script
.\start_backend.bat
```

**Terminal 2 (New PowerShell window):**
```powershell
# Navigate to project
cd "C:\Users\admin\New folder\fashion-stylist"

# Run frontend startup script  
.\start_frontend.bat
```

---

### Method 2: Manual (More Control)

**Terminal 1 - Backend:**
```powershell
cd "C:\Users\admin\New folder\fashion-stylist\backend"
python app.py
```

**You should see:**
```
WARNING: This is a development server. Do not use it in production.
Press CTRL+C to quit
 * Restarting with reloader
 * Debugger is active!
 * Running on http://127.0.0.1:5000
```

**Terminal 2 - Frontend:**
```powershell
cd "C:\Users\admin\New folder\fashion-stylist\frontend"
python app.py
```

**You should see:**
```
WARNING: This is a development server. Do not use it in production.
Press CTRL+C to quit
 * Running on http://127.0.0.1:3000
```

---

## 🌐 OPEN IN BROWSER

Once both servers are running, open your browser and go to:

```
http://localhost:3000
```

**🎉 Your AI Fashion Stylist is now running!**

---

## ✨ What You Can Do Now

### 1. Get Style Recommendations
- Select your gender/style preference
- Choose an occasion (casual, office, party, etc.)
- Pick the weather
- Describe your style preferences
- **Click "Get Recommendations"**
- Get 3 complete outfits with full details!

### 2. Analyze Your Outfit
- Upload a photo of your current outfit
- Add improvement questions (optional)
- **Click "Analyze Outfit"**
- Get AI styling suggestions

### 3. Chat with Your Stylist
- Ask any fashion question
- Get instant expert answers
- Have a real conversation!

---

## 🛑 How to Stop

Press **Ctrl+C** in each terminal to stop the servers.

---

## 🆘 Troubleshooting

### Problem: "This site can't be reached"
**Solution:** Make sure both backend AND frontend are running
- Backend: Terminal showing "Running on http://127.0.0.1:5000"
- Frontend: Terminal showing "Running on http://127.0.0.1:3000"

### Problem: "Invalid API key" error
**Solution:** 
1. Check `backend\.env` file has your real Gemini API key
2. Make sure there are no extra spaces
3. Restart the backend server

### Problem: "Port already in use"
**Solution:** Another app is using port 5000 or 3000
- Change port in `backend/app.py` (port=5000) or `frontend/app.py` (port=3000)
- Or close the other application

### Problem: "ModuleNotFoundError"
**Solution:** 
```powershell
cd "C:\Users\admin\New folder\fashion-stylist"
pip install -r requirements.txt
```

### Problem: "Connection refused"
**Solution:** 
- Make sure frontend server is running (Terminal 2)
- Make sure backend server is running (Terminal 1)
- Refresh browser (F5)

---

## 📋 Checklist Before Running

- [ ] You have a Gemini API key
- [ ] You edited `backend\.env` with your API key
- [ ] Python 3.8+ is installed (`python --version`)
- [ ] All packages installed (`pip list` shows Flask, google-generativeai, etc.)
- [ ] You have 2 PowerShell windows ready
- [ ] Modern browser installed (Chrome, Firefox, Safari, Edge)

---

## 🎊 You're All Set!

Everything is installed and ready. Just:

1. ✅ Get your API key from makersuite.google.com
2. ✅ Add it to `backend\.env`
3. ✅ Run `start_backend.bat` in one terminal
4. ✅ Run `start_frontend.bat` in another terminal
5. ✅ Open http://localhost:3000
6. ✅ Enjoy! 👗✨

---

## 📞 Quick Reference

| Action | Command |
|--------|---------|
| Check Python | `python --version` |
| Install packages | `pip install -r requirements.txt` |
| Start backend | `cd backend` then `python app.py` |
| Start frontend | `cd frontend` then `python app.py` |
| Access app | `http://localhost:3000` |
| Stop server | `Ctrl+C` |

---

**Made with ❤️ | Your AI Fashion Stylist Awaits! 👗✨**

For more help, see:
- `QUICK_START.md` - 5-minute overview
- `README.md` - Complete documentation
- `API_DOCUMENTATION.md` - API reference
